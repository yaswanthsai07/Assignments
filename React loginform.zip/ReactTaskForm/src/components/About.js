import React from 'react';

function About() {
  return (
    <div>
      <h2>About Us</h2>
      <p>Welcome to EY website</p>
    </div>
  );
}

export default About;
